#ifndef MAINMATH_H
#define MAINMATH_H
#include <math.h>
#include <string>

namespace  myMath  {

    class Triangle
    {
            public :
            double ab,bc,ac;
            std::string strError;
            bool err;
            private :
    };

   Triangle ForwardTriangleSide(Triangle data);
}

#endif // MAINMATH_H
