#ifndef TRIANGLEWIDGET_H
#define TRIANGLEWIDGET_H

#include <QWidget>
#include "mainmath.h"

#include <QHash>

namespace Ui {
class TriangleWidget;
}


class TriangleWidget : public QWidget
{
    Q_OBJECT

    enum TypeTriangle {
        equilateralTriangle, /// ровностороний
        isoscelesTriangle, /// равнобедренный
        orthogonalTriangle, /// прямоугольный
    };

public:
    explicit TriangleWidget(QWidget *parent = nullptr);
    ~TriangleWidget();

public slots:
    void startTask();

signals:
    void signalResult(const myMath::Triangle);

private:
    Ui::TriangleWidget *ui;
    myMath::Triangle result;
    int taskFlag = 0;
    QHash<int, QString> hashFlag;

private slots:
    // вызаваются при смене соотвецтвующей стороны
    void upAB(double ab);
    void upBC(double bc);
    void upAC(double ac);
    // вызывается при смене типа трегольника
    void setTypeTriangle(int type);
};

#endif // TRIANGLEWIDGET_H
