#include "trianglewidget.h"
#include "ui_trianglewidget.h"

#include <QSpinBox>

TriangleWidget::TriangleWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TriangleWidget)
{
    ui->setupUi(this);

    // список  разновидностей треугольников
    hashFlag[TypeTriangle::equilateralTriangle] = "Прямоугольный";
    hashFlag[TypeTriangle::isoscelesTriangle] = "Ровностороний";
    hashFlag[TypeTriangle::orthogonalTriangle] = "Ровнобедренный";

    // заполняет comboBox, типами треугольников
    ui->triangleType->insertItem(TypeTriangle::equilateralTriangle, hashFlag.value(TypeTriangle::equilateralTriangle));
    ui->triangleType->insertItem(TypeTriangle::isoscelesTriangle, hashFlag.value(TypeTriangle::isoscelesTriangle));
    ui->triangleType->insertItem(TypeTriangle::orthogonalTriangle, hashFlag.value(TypeTriangle::orthogonalTriangle));

    // получаем начальные данные из spinBox
    result.ab = ui->spinBoxAB->value();
    result.bc = ui->spinBoxBC->value();
    result.ac = ui->spinBoxAаnnect(ui->spinBoxAB, SIGNAL(valueChanged(double)), this, SLOT(upAB(double)));
    connect(ui->spinBoxBC, SIGNAL(valueChanged(double)), this, SLOT(upBC(double)));
    connect(ui->spinBoxAC, SIGNAL(valueChanged(double)), this, SLOT(upAC(double)));
}

TriangleWidget::~TriangleWidget()
{
    delete ui;
}

void TriangleWidget::startTask()
{
    result = myMath::ForwardTriangleSide(result);

    // вызываем сигнал об окончании решения задачи
    emit signalResult(result);
}

void TriangleWidget::upAB(double ab)
{
    result.ab = ab;
    startTask();
}

void TriangleWidget::upBC(double ac)
{
    result.ac = ac;
    startTask();
}

void TriangleWidget::upAC(double ac)
{
    result.ac = ac;
    startTask();
}

void TriangleWidget::setTypeTriangle(int type)
{

}
