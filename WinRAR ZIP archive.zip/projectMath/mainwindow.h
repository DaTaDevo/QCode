#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QListWidgetItem>
#include <QMainWindow>
#include <QHash>

#include "trianglewidget.h"
#include "squarewidget.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

    enum Tasks {
        taskTriangle, // 0
        taskKvadrat, // 1
    };

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    //void upWidget(int taskNum);
    void upWidget(int taskNum);
private:
    Ui::MainWindow *ui;
    //  таблица задач
    QHash<int, QWidget*> hashTask;
    int preTask = -1;
};

#endif // MAINWINDOW_H
