#include "mainmath.h"
#include <QDebug>

namespace myMath  {

    myMath::Triangle myMath::ForwardTriangleSide(myMath::Triangle data)
    {
        Triangle output;

        // проверка на существование треугольника по трем сторонам
        if ((data.ab + data.bc > data.ac) && (data.bc + data.ac != data.ab) && (data.ab+data.ac != data.bc))
        {
            qDebug() << "Треугольник може сущ";

        } else  {
//            if ((data.ab > 0 && data.ac > 0) || (data.ab > 0 && data.bc > 0) || (data.bc > 0 && data.ac > 0)) {
//                qDebug() << "It ok"
//            }
            qDebug() << "fdg";
        }

        return output;
    }
}
