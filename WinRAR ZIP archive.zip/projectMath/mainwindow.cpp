#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    hashTask[Tasks::taskTriangle]  = new TriangleWidget;
    hashTask[Tasks::taskKvadrat] = new SquareWidget;

    ui->listTask->addItem("Triangle");
    ui->listTask->addItem("Kvadrat");

    connect(ui->listTask, SIGNAL(currentRowChanged(int)), this, SLOT(upWidget(int)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::upWidget(int taskNum)
{
    if (preTask >= 0 && preTask != taskNum) {
        ui->layoutTask->removeWidget(hashTask.value(preTask));
    }
    ui->layoutTask->addWidget(hashTask.value(taskNum));
    preTask = taskNum;
}
